import { Context, Schema } from 'koishi';
export declare const name = "sticker-convert";
export declare const usage = "\n## QQ \u8868\u60C5\u8F6C\u6362\u63D2\u4EF6\n\n\u5C06 QQ \u8868\u60C5\u5305\u8F6C\u6362\u4E3A\u53EF\u4FDD\u5B58\u7684\u56FE\u7247\u6216\u6587\u4EF6\u683C\u5F0F\u3002\n\n### \u4F7F\u7528\u65B9\u6CD5\n1. \u56DE\u590D\u5305\u542B\u8868\u60C5\u7684\u6D88\u606F\uFF0C\u53D1\u9001 \"\u8868\u60C5\u8F6C\u6362\" \u5373\u53EF\u8F6C\u6362\u5E76\u53D1\u9001\n\n### \u652F\u6301\u683C\u5F0F\n- \u9759\u6001\u56FE\u7247\uFF08jpg/png/webp\uFF09\uFF1A\u8F6C\u4E3A\u666E\u901A\u56FE\u7247\u6216\u6587\u4EF6\n- \u52A8\u6001\u56FE\u7247\uFF08gif\uFF09\uFF1A\u8F6C\u4E3A\u6587\u4EF6\u6216\u56FE\u7247\n- \u5B98\u65B9\u8868\u60C5\uFF08face\uFF09\uFF1A\u8F6C\u4E3A\u6587\u4EF6\u6216\u56FE\u7247\n";
export interface Config {
    staticImageMode: 'buffer' | 'file';
    gifMode: 'buffer' | 'file';
    debug: boolean;
}
export declare const Config: Schema<Config>;
export declare function apply(ctx: Context, config: Config): void;
